package com.empresa.millena.carapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.TextView


class TrueActivity : AppCompatActivity() {

    override fun onCreate(icicle: Bundle?) {
        super.onCreate(icicle)
        //View
        setContentView(R.layout.activity_welcome)
        val textview = findViewById<TextView>(R.id.text)
        //Args
        val args = intent.extras
        val imc = args.getString("imc")
        textview.text = "Este é seu imc $imc e ele está ideal"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item?.itemId == android.R.id.home){
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}

