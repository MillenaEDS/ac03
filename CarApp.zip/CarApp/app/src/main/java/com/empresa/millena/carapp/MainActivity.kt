package com.empresa.millena.carapp

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast


class MainActivity : DebugActivity() {
    //propriedade para acessar o contexto de qualquer lugar
    private val context: Context get() = this

    override fun onCreate(icile: Bundle?) {
        super.onCreate(icile)
        setContentView(R.layout.activity_calculo)
        onClick(R.id.botao) { onClickLogin() }
    }

    fun onClickLogin() {
        val altura = getTextString(R.id.input_altura).toDouble()
        val peso = getTextString(R.id.input_peso).toDouble()
        val imc = peso / (altura * altura)
        if (imc >= 19.0 && imc <=25.8) {
            val intent = Intent(this, TrueActivity::class.java)
            val parametros = Bundle()
            parametros.putString("imc", imc.toString())
            intent.putExtras(parametros)
            startActivity(intent)
        } else {
            val intent = Intent(this, FalseActivity::class.java)
            val parametros = Bundle()
            parametros.putString("imc", imc.toString())
            intent.putExtras(parametros)
            startActivity(intent)
        }


    }



}
